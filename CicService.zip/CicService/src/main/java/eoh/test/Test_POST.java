package main.java.eoh.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.gson.Gson;

import main.java.eoh.cicservice.domain.CicDTO;

public class Test_POST {

	Test_POST() {
		try {

			URL url = new URL("http://127.0.0.1:8080/CicService/eoh/cicservice/cic");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");

			String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());

			Gson gson = new Gson();
			String gString = gson.toJson(new CicDTO( "EMAIL", "I am your father..","....Luke, together we can rule...", "SYSTEM", time, 2l));
			System.out.println("\n\n" + gString);
			
			try (OutputStreamWriter printout = new OutputStreamWriter(conn.getOutputStream())) {
				printout.write(gString);
				printout.flush();
			}

			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode()+" " +conn.getResponseMessage());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}

			conn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}

	}

	public void post(String url, String param) throws Exception {
		String charset = "UTF-8";
		URLConnection connection = new URL(url).openConnection();
		connection.setDoOutput(true); // Triggers POST.
		connection.setRequestProperty("Accept-Charset", charset);
		connection.setRequestProperty("Content-Type", "application/json;charset=" + charset);

		try (OutputStream output = connection.getOutputStream()) {
			output.write(param.getBytes(charset));
		}

		InputStream response = connection.getInputStream();
	}

	public static void main(String[] args) {
		new Test_POST();
		
	}

}
