package main.java.eoh.cicservice.webcontroller;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.google.gson.Gson;

import main.java.eoh.cicservice.domain.CicDTO;
import main.java.eoh.cicservice.domain.CicDaoI;

@Named
@RequestScoped
public class Controller {

	@Inject
	private CicDaoI cicDaoI;

	private Long cicId;
	private String msg;

	// @SuppressWarnings("unused")
	public String retrieveEmailByCicId(Long cicId) {
		CicDTO cic = cicDaoI.getCicWithId(cicId);
		if (cic != null) {
			msg = "Hello, " + cic.getCicType() + " " + cic.getSubject() + "!";
		} else {
			msg = "No such cicId exists! Use 'emuster' or 'jdoe'";
		}
		Gson gson = new Gson();
		System.out.println("\n\n" + gson.toJson(cic));
		return gson.toJson(cic);
	}

	public void persistCic(CicDTO cic) {
		cicDaoI.persistCic(cic);
	}

	public Long getCicId() {
		return cicId;
	}

	public String getMsg() {
		return msg;
	}

	public void setCicId(Long cicId) {
		this.cicId = cicId;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

}
