package main.java.eoh.cicservice.domain;

import java.sql.Timestamp;

//import java.sql.Timestamp;
//import java.util.ArrayList;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

public class EmailDao implements CicDaoI {

	@Inject
	private EntityManager entityManager;

	@Inject
	private UserTransaction utx;

	@Override
	public CicDTO getCicWithId(Long cicId) {

		try {
			CicDTO cic = null;
			try {
				System.out.println(cicId + " : cicId");
				utx.begin();
				Query query = entityManager.createQuery("select u from CicDTO u where u.cicId = :cicId");
				query.setParameter("cicId", cicId);
				cic = (CicDTO) query.getSingleResult();
			} catch (NoResultException e) {
				System.out.println(cic + " : NoResultException");
				throw new Exception("CicId not found");
			}
			utx.commit();
			return cic;
		} catch (Exception e) {
			try {
				utx.rollback();
			} catch (SystemException se) {
				throw new RuntimeException(se);
			}
			throw new RuntimeException(e);
		}
	}

	public void persistCic(CicDTO cic) {
		try {
			try{
				 utx.begin();
				 entityManager.persist(cic);

			} finally {
				 utx.commit();
			}
		} catch (Exception e) {
			System.out.println("Rollback on persist: " + e.getMessage());
			e.printStackTrace();
//			entityManager.getTransaction().rollback();
			try {
				utx.rollback();
			} catch (IllegalStateException | SecurityException | SystemException e1) {
				e1.printStackTrace();
			}

		}
	}
}