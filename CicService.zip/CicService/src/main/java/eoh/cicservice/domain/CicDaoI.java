package main.java.eoh.cicservice.domain;

public interface CicDaoI {

	public CicDTO getCicWithId(Long cicId);

	public void persistCic(CicDTO icDTO);
}
