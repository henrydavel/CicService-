package main.java.eoh.cicservice.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Customer", schema = "PUBLIC")
public class CustomerDTO {

	@Id
	@Column(name = "customerId")
	@SequenceGenerator(name = "seq", initialValue = 002, allocationSize = 100)
	private Long customerId;
	
	private String customerName;
	
	private String emailAddress;

	public Long getCustomerId() {
		return customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

}