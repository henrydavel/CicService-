package main.java.eoh.cicservice.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Cic", schema = "PUBLIC")
public class CicDTO {
	
	public CicDTO(){}

	public CicDTO(String cicType, String subject, String body, String sourceSystem, String cicTimestamp,
			Long cicCustomerID) {
		super();
//		this.cicId = cicId;
		this.cicType = cicType;
		this.subject = subject;
		this.body = body;
		this.sourceSystem = sourceSystem;
		this.cicTimestamp = cicTimestamp;
		this.cicCustomerID = cicCustomerID;
	}

	@Id
	@Column(name = "cicId")
	@GeneratedValue
	private Long cicId;

	private String cicType;
	private String subject;
	private String body;
	private String sourceSystem;
	
	private String cicTimestamp;

	private Long cicCustomerID;

	public Long getCicId() {
		return cicId;
	}
	public String getCicType() {
		return cicType;
	}

	public String getSubject() {
		return subject;
	}

	public String getBody() {
		return body;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public String getCicTimestamp() {
		return cicTimestamp;
	}

//	public void setCicId(Long cicId) {
//		this.cicId = cicId;
//	}
	public void setCicType(String cicType) {
		this.cicType = cicType;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public void setCicTimestamp(String cicTimestamp) {
		this.cicTimestamp = cicTimestamp;
	}

	public Long getCicCustomerID() {
		return cicCustomerID;
	}

	public void setCicCustomerID(Long cicCustomerID) {
		this.cicCustomerID = cicCustomerID;
	}

}