package main.java.eoh.cicservice;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import main.java.eoh.cicservice.domain.CicDTO;
import main.java.eoh.cicservice.webcontroller.Controller;

@Path("/cicservice")
public class CicService {

	@Inject
	Controller controller;

	@GET
	@Path("/sayHello")
	public String sayHello() {
		return "<h1>Hello World</h1>";
	}

	@GET
	@Produces("application/json")
	@Path("/cic/{cicId}")
	public String getCicWithIdString(@PathParam("cicId") String cicId) {
		Long value;
		try {
			value = Long.parseLong(cicId);
		} catch (Exception e) {
			return "{\"error\":\"" + "Please enter a valid Long value" + "\"}";
		}
		return "{\"result\":\"" + controller.retrieveEmailByCicId(value) + "\"}";
	}
	
	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/cic")
	public String persistCic(CicDTO cic) {
//	    Response.ResponseBuilder builder = null;

	    try {
	        controller.persistCic(cic);
//	        builder = Response.ok();

	    } catch (Exception e) {
	        Map<String, String> responseObj = new HashMap<String, String>();
	        responseObj.put("error", e.getMessage());
	        return Response.status(Response.Status.BAD_REQUEST).entity(responseObj).toString();
	    }

	    return "Persisted CIC";
	}

	
//	@POST
//	@Consumes({ MediaType.APPLICATION_JSON })
//	@Produces({ MediaType.APPLICATION_JSON })
//	@Path("/cic")
//	public Response persistCic(CicDTO cic) {
//	    Response.ResponseBuilder builder = null;
//
//	    try {
//	        controller.persistCic(cic);
//	        builder = Response.ok();
//
//	    } catch (Exception e) {
//	        Map<String, String> responseObj = new HashMap<String, String>();
//	        responseObj.put("error", e.getMessage());
//	        builder = Response.status(Response.Status.BAD_REQUEST).entity(responseObj);
//	    }
//
//	    return builder.build();
//	}

}
	
	
	
	

