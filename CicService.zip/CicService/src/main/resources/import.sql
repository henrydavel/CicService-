INSERT INTO Customer (customerId, customerName, emailAddress) VALUES (000, 'LEIA','princess@resistence.uni');
INSERT INTO Customer (customerId, customerName, emailAddress) VALUES (001, 'LUKE','luke@resistence.uni');

INSERT INTO Cic (cicId, cicType, subject, body, sourceSystem, cicTimestamp, cicCustomerID) VALUES (0,'EMAIL', 'Help me Obiwan, we need you...', '....blahh force....','SYSTEM', '1972-01-01 13:42:24', (select customerId from Customer where customerName ='LEIA'));
INSERT INTO Cic (cicId, cicType, subject, body, sourceSystem,cicTimestamp, cicCustomerID) VALUES (1,'EMAIL', 'Han, where are you ?', '....blahh I saw Ben...','SYSTEM','1972-01-01 13:42:24', (select customerId from Customer where customerName ='LEIA'));


